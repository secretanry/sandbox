import React, { useState } from 'react';
import './App.css'; // Импортируем файл стилей
import Header from './Header';
import Footer from './Footer';

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [keywords, setKeywords] = useState([]); // Состояние для хранения ключевых слов
  const [exclusionKeywords, setExclusionKeywords] = useState([]); // Состояние для хранения слов-исключений

  const handleSearchChange = (event) => {
    const { value } = event.target;
    setSearchTerm(value);
  };

  const handleSearchSubmit = (event) => {
    event.preventDefault();
    // Отправка запроса на бэкэнд
    console.log('Отправка запроса на бэкэнд:', searchTerm);
  };

  const handleAddKeyword = () => {
    if (searchTerm.trim() !== '') {
      setKeywords([...keywords, searchTerm.trim()]); // Добавляем ключевое слово в список
      setSearchTerm(''); // Очищаем поисковую строку после добавления ключевого слова
    }
  };

  const handleAddExclusionKeyword = () => {
    if (searchTerm.trim() !== '') {
      setExclusionKeywords([...exclusionKeywords, searchTerm.trim()]); // Добавляем слово-исключение в список
      setSearchTerm(''); // Очищаем поисковую строку после добавления слова-исключения
    }
  };

  return (
    <div>
      <Header />
      <h1>Сайт с поиском на React</h1>
      <form onSubmit={handleSearchSubmit} className="search-form">
        <input
          type="text"
          placeholder="Поиск..."
          value={searchTerm}
          onChange={handleSearchChange}
          className="search-input"
        />
        <button type="submit" className="search-button">Поиск</button>
        <button type="button" className="add-keyword-button" onClick={handleAddKeyword}>+</button>
        <button type="button" className="add-keyword-button" onClick={handleAddExclusionKeyword}>-</button>
      </form>
      <div className="keywords-list">
        {keywords.map((keyword, index) => (
          <span key={index} className="keyword">{keyword}</span>
        ))}
      </div>
      <div className="exclusion-keywords-list">
        {exclusionKeywords.map((exclusionKeyword, index) => (
          <span key={index} className="exclusion-keyword">{exclusionKeyword}</span>
        ))}
      </div>
      <br />
      <Footer />
    </div>
  );
};

export default App;
