import React from 'react';
import Article from './Article';

const MainContent = () => {
  return (
    <main>
      <Article 
        title="Заголовок статьи 1"
        content="Содержание статьи 1"
      />
      <Article 
        title="Заголовок статьи 2"
        content="Содержание статьи 2"
      />
    </main>
  );
};

export default MainContent;
