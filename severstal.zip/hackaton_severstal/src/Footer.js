import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>© 2024 Мой сайт</p>
    </footer>
  );
};

export default Footer;
