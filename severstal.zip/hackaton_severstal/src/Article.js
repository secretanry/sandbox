import React from 'react';

const Article = (props) => {
  const { title, content } = props;
  
  return (
    <article>
      <h2>{title}</h2>
      <p>{content}</p>
    </article>
  );
};

export default Article;
